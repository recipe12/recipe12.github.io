# Cooked Chickpeas

Easy recipe for cooked chickpeas. Can be add to salads, rice, or almost anything else. 

- ⏲️ Prep time: 1 min
- 🍳Cook time: 15 min
- 🍽️ Servings: 3

## Ingredients

- 1 can chickpeas / garbanzo beans, drained
- 1 tbsp olive oil
- 1 tsp garlic powder
- 1 tsp cumin
- 1 tsp paprika
- 1 tsp cayenne pepper

## Directions

1. Heat oil in pan. Add chickpeas and seasonings. 
2. Cook over medium-high heat for 10-15 minutes. Salt and pepper to taste.

## Contribution

- Carl Zimmerman -- [website](https://codingwithcarl.com)

;tags: basic beans
