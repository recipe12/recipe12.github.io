# Spatchcock Chicken

## Ingredients

- 2 (3 1/2) pound whole chickens, wingtips removed
- 2 teaspoons salt
- 1 teaspoon dried tarragon
- 1 teaspoon paprika
- 1/4 teaspoon black pepper
- 4 teaspoons olive oil
- 2 lemons, thinly sliced and seeded

## Directions

1. Preheat oven to 450 degrees F (230 degrees C). Line a large rimmed baking sheet with foil.
2. Place chicken, breast side down, on a work surface. Starting at the tail end, cut along both sides of backbone with kitchen shears. Remove backbone. Grabbing hold of both sides of the chicken, open it like a book. Turn breast side up. Push down on each side of breast with your hands until you hear it crack. Flatten chicken and transfer to one short end of the prepared baking sheet. Repeat with the second chicken.
3. Combine salt, tarragon, paprika, and pepper in a small bowl. Stir in oil. Run your fingers under chicken skin and rub tarragon paste under skin. Slide lemon slices under skin, in a single layer.
4. Roast until skin is crisp and an instant-read thermometer inserted into thickest part of breast reads 165 degrees F, about 35 minutes. Let stand 5 minutes before cutting each chicken into 8 pieces.

## Contribution

Front3ndNinja - [Website](https://github.com/Front3ndNinja)

;tags: basic bread chicken