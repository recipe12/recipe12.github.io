# Simple sauce

This is a simple and well known recipe. It goes by many names and this recipe is a starting point for many sauces, eg '1000 island sauce'.

## Ingredients

+ Tomato sauce.
+ Mayonaise

## Directions

1. Mix one part tomato sauce with two parts mayonaise. What 'part' means is up to you, because that will determine how much sauce you will have. You can also adjust this to your liking. More tomato sauce, more acidity. More mayonaise, more sweetness.
2. Enjoy!

## Contribution

By el3ctr0lyte [github](https://github.com/el3ctr0lyte)

;tags: basic quick sauce
