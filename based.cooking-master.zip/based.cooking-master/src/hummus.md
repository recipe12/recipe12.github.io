# Hummus

## Ingredients

- One can of garbonzo beans
- About 3 tablespoons of tahini (also known as tehina)
- A spash of Lemmon Juice
- A splash of Olive Oil

## Directions

1. Thuroughly rinse garbonzo beans and remove any skins
2. Put all ingredients into a small food processor and chop until desired thickness is reached
3. You may have to add more olive oil or lemmon juice to reach your desired thickness (exact measurements of these ingredients were not given because you may like your hummus to be a different thickness than someone else, feel free to experiment)
4. Once your desired thickness has been reached place in a sealale container and refrigerate until you are ready to eat

## Contribution

- Jacob Smith - [website](https://jacobwsmith.xyz)

;tags: basic snack spread
