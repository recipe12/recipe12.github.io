# Party Mimosa

## Ingredients

- 1 (12 ounce) can apricot-mango nectar
- 1 (12 ounce) can pineapple juice
- 1 (6 ounce) can frozen orange juice concentrate, thawed and undiluted
- 1 (750 milliliter) bottle cold champagne
- 3/4 cup cold water

## Directions

1. Stir together apricot nectar, pineapple juice, water, and orange juice concentrate in a large pitcher until combined. Pour in bottle of sparkling wine just before serving.

## Contribution

Front3ndNinja - [Website](https://github.com/Front3ndNinja)

;tags: drink sweet breakfast