# Tortellini

## Ingredients

- Tortellini
- 1-2 eggs
- Cooking cream
- Cheese (optional)

## Directions

1. Buy tortellini (prefer meat or spinach).
2. Bring water to a boil.
3. Add salt to water only after boiling.
4. Add tortellini in.
5. Cook for 3 minutes.
6. Drain water from the pot while keeping tortellini in.
7. Add cooking cream and mix at medium heat until reduced a bit so it's more creamy.
8. Turn off the heat and add 1 or 2 eggs.
9. Mix in and let eggs cook using heat from the pot and tortellini.
10. Serve on a plate. Add pepper, more salt if needed, and optionally, shredded cheese on top for extra creaminess.

## Contribution

- Teo Dragovic - [website](https://teodragovic.com)

;tags: italian pasta quick
