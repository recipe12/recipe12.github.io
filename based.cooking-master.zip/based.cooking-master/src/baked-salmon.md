# Baked Salmon

Simple method for making a good serving of salmon. Goes well with just about anything.

- ⏲️ Prep time: 5 min
- 🍳Cook time: 19 min

## Ingredients

- Salmon Steaks
- Red Pepper Flakes
- Lemon Juice
- Butter
- Cooking oil / spray
- Aluminum Foil

## Directions

1. Season salmon with salt, black pepper, and red pepper to taste. 
2. Spray or rub in cooking oil on aluminum foil and place on cookie sheet or in baking pan.
3. Squeeze lemon juice and place a teaspoon of butter on each salmon steak.
4. Bake at 400°F / 200°C for 19 mins.


## Contribution

- Carl Zimmerman -- [website](https://codingwithcarl.com)

;tags: basic fish
