# Tomato and Grilled Bell Pepper soup

- 🍳Cook time: 30 min
- 🍽️Servings:12

Can be prepared the night before and kept frozen for a week or two.

## Ingredients
- 10 tomatoes
- 2 red bell peppers
- 2 onions
- 1 clove of garlic
- 1L stock or broth
- ¾t Cayenne pepper
- 1t paprika powder
- 3t bruschetta herbs
- 1t oregano
- 1t giner syrup
- 2T olive oil
- 2T heavy cream


## Directions
1. Halve, deseed and grill the bell peppers in an oven or on a grill. Remove skin after grilling.
2. Skin and quarter tomatoes.
3. Sauté onion and crushed garlic in a large soup pan with olive oil.
4. Add broth/stock, tomatoes, bell paper and purée with a stick blender.
5. Add spices, syrup and cream.

## Contribution
- Thijs Wester - [website](https://twester.tk)

;tags: soup
