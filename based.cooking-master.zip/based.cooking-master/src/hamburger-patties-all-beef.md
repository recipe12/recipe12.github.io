# Hamburger Patties (basic, all-beef)

🍽️ Servings: 4 patties

## Ingredients

-	1 lb ground beef, 20% or more fat ratio
-	Onion, chopped or powder (optional)
-	Garlic, chopped or powder (optional)

## Directions

1.	Form patties with the beef.  Use high-fat ground beef, you won't need oil.
2.	Place into a pan, pre-heated or otherwise, at medium/med-high temperature.
3.  Add salt, pepper, and optional seasonings.
4.	Cook until done, flipping occasionally to prevent burning.

## Contribution

- James Hendrie
            
;tags: american quick beef basic
