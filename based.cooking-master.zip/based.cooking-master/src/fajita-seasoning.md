# Fajita Seasoning

Simple seasoning mix similar to Old El Paso. Can be used for any Mexican dishes or plain meats.

## Ingredients

- 1/2 tsp Garlic Powder
- 1/2 tsp Onion Powder
- 1/2 tsp Paprika
- 1/2 tsp Smoked Paprika
- 1/2 tsp Ground Cumin
- 1/2 tsp Ground Coriander 
- 1/2 tsp Oregano
- 1/2 tsp Cayenne Pepper
- 1 tsp Salt
- 1 tsp Brown Sugar
- 1.5 tsp Chili Powder

## Directions

1. Mix seasonings in a bowl. Adjust amounts depending on how much is needed. 

## Contribution

- Carl Zimmerman -- [website](https://codingwithcarl.com)

;tags: basic mexican
