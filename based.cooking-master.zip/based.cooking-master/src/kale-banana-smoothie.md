# Kale Banana Smoothie

- ⏲️ Prep time: 10 min
- 🍳Cook time: 10 min
- 🍽️ Servings: 1

## Ingredients

- 16 fluid ounces coconut water, chilled
- 1 banana
- 1/2 avocado, peeled and pitted
- 1/2 cup packed kale
- 1/2 lemon, juiced
- 1 pinch cayenne pepper

## Directions

1. Put coconut water, banana, avocado, kale, lemon juice, and cayenne pepper in blender; blend until smooth, about 30 seconds.

## Contribution

Front3ndNinja - [Website](https://github.com/Front3ndNinja)

;tags: drink sweet breakfast