# Simple Tuna Salad

- ⏲️ Prep time: 5 min
- 🍽️ Servings: 3

## Ingredients 

- 1 (7 oz) can white tuna, drained
- 6 tablespoons mayonnaise 
- 1 tablespoons sweet pickle relish
- A pinch of garlic powder (optional)

## Directions

1. In a medium bowl, stir together tuna, mayonnaise, and relish.
2. Season with garlic powder, salt, and pepper if wanted.

## Contribution

scary90

;tags: quick basic tuna fish
