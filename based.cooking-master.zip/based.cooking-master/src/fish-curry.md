# Fish Curry 

Best served with white rice

- 🍳Cook time: 30 min
- 🍽️ Servings:5

## Ingredients
- 3T neutral oil
- 1 onion
- 1 red onion
- 2 cloves of garlic
- 4cm ginger
- 1 red pepper
- 1t curry powder
- 250g green beans
- 4 tomatoes
- 200ml fish broth
- 200ml coconut milk
- 400g fish fillet (white fish)


## Directions
1. Boil green beans for 10 minutes
2. Cut onions, tomato, garlic and fish.
3. Heat oil on a wok and sauté the onion and garlic
4. Add beans, tomato, broth and spices and boil for 6 minutes
5. Add coconut milk, fish and pepper (whole) and boil for an additional 6 minutes.


## Contribution
- Thijs Wester - [website](https://twester.tk)

;tags: thai
