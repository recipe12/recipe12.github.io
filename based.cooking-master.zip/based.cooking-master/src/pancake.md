# Pancake
Here is a simple Pancake recipe

## Ingredients
- 200g wheat flour
- 200 ml milk
- 2 Eggs
- 2 teaspoon sugar
- 1 teaspoon baking soda
- a little bit of salt

## Directions
1. combine all ingredients all in a bowl and stir
2. preheat a pan and add some oil
3. Pour or scoop the batter onto the pan
4. Brown on both sides

## Contribution

BeFe

;tags: quick basic breakfast sweet cake pancake
