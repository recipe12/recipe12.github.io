# Pilaf

Popular central asian and middle eastern dish.
High in nutrition, designed to be prepared and eaten communally.

## Ingredients

- long grain [rice](rice.html): 1 kg
- meat (lamb or any other kind of meat): 1.5 kg
- carrots
- onions
- raisins, cardamom, paprika, coriander, cinnamon, cumin, turmeric (all optional)

## Directions

1. Put 250 ml of cooking oil in a cauldron and heat it until the oil is boiling, add a head of onion until it is black, then throw it out.
2. Throw coarsely chopped meat into the cauldron and let it boil until it's golden brown, then add a pinch of salt.
3. Add 500 g of chopped onions, then wait 2 minutes and add 500 g of sliced carrots, boil for another 2 minutes.
4. Add 500 ml of water diluted with tomato paste, boil for 5 minutes.
5. Rinse the rice and put it into the cauldron but do not mix.
6. Add another 500 ml of water diluted with tomato paste and wait until it is boiling.
7. Reduce the heat to minimum, then add two table spoons of salt.
8. Close the cauldron and leave it on low heat for 1.5-2 hours.
9. 1 hour before it is ready(or when you can't see water above the rice), add 5 cloves of garlic.
10. You can now turn over the rice if it is undercooked and add some raisins.
11. Keep boiling until all water is evaporated.

## Contribution

- Roman Mirzayev

;tags: uzbek rice lamb
