# Tuna Sub

Use the best tuna you can find. I like oil-packed but water is OK. Someone you know has a tuna salad recipe. 

## Ingredients

- 1 recipe of your favorite tuna salad 
- Sandwich bun or bread (a good one)
- Thinly sliced cheese (your favorite)
- Sliced tomatoes
- Baby spinach leaves
- Pickles
- Mayo and mustard
- Other sandwich toppings (very little out of bounds here).

## Directions

1. Lightly toast one side of the bun
2. Add cheese to bottom of bun
3. Spread a layer of tuna salad
4. Place several spinach leaves on top bun
5. Add sliced tomatoes
6. Add pickle slices
7. Season with salt and pepper to taste
8. Combine halves and enjoy.

## Contribution
- I don't think you could call it that.

;tags: fish sandwich quick
