# Dried tomato & plum bread spread

Quick and simple bread spread.

## Ingredients

- 10 dried plums
- 1 jar of dried tomatoes
- 1 tsp of smoked paprika
- pinch of dried coriander (optional)
- pinch of chilli (optional, if you like it to be spicy)

## Directions

1. Put plums in hot water from kettle for couple of minutes, in order to make them softer.
2. After that put plums (without the water) and rest of the ingredients into blender and mix it until you're satisfied.
3. If you want to make it more liquid you can add water from the plums.


## Contribution

- Patryk Niedźwiedziński - [website](https://niedzwiedzinski.cyou)

;tags: bread quick snack spread
