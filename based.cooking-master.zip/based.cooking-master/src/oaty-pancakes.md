# Oaty Pancakes

- ⏲️ Prep time: 10 min
- 🍳Cook time: 10 min
- 🍽️ Servings: 4

## Ingredients

- 3⁄4 cup milk
- 3⁄4 rolled oats
- 1 egg
- 1⁄2 teaspoon salt
- 2-3 tablespoon sugar
- 1⁄2 cup flour
- 2 teaspoon baking powder
- 2 teaspoon baking soda
- 25g butter (melted)

## Directions

1. Pour milk over rolled oats. Add remaining ingredients.
2. Mix with fork (or in a food processor) just enough to
combine ingredients.
3. Put spoonfuls of mixture onto preheated, greased or
sprayed griddle or fry pan. Turn spoon for round
pancakes.
4. Turn pancakes as soon as bubbles form and
burst in the middle. Slide thin metal blade under
pancake and flip over. Second side is cooked when
centre springs back.
5. Put a dab of butter on cooked surface of several
pancakes.
6. Pile up so butter is between pancakes. Pour
syrup over before serving.
7. Serve Oaty pancakes for breakfast or brunch, with juice
or coffee. Pour syrup over the pile of buttered pancakes
and serve bacon or sausages alongside if you like.

## Contribution

Puremana

;tags: breakfast quick sweet cake pancake
