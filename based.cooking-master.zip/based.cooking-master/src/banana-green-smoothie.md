# Banana Green Smoothie

## Ingredients

- 2 cups baby spinach leaves, or to taste
- 1 banana
- 1 carrot, peeled and cut into large chunks
- 3/4 cup plain fat-free Greek yogurt, or to taste
- 3/4 cup ice
- 2 tablespoons honey

## Directions

1. Put spinach, banana, carrot, yogurt, ice, and honey in a blender; blend until smooth.

## Contribution

Front3ndNinja - [Website](https://github.com/Front3ndNinja)

;tags: drink sweet breakfast