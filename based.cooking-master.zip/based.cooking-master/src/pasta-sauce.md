# Pasta sauce

This is very simple pasta sauce.
Unlike modern store-bought sauces, there is no added sugar, only the subtle taste of San Marzano tomatoes.

## Ingredients

- a can of San Marzano tomatoes (or home-grown with some extra pulp)
- onion or garlic
- olive oil
- oregano or basil (Dried or diced)

## Directions

1. Heat up olive oil on saucepan.
2. Add and roast either diced or grated onion or crush and sliced garlic until translucent.
3. Add San Marzano tomatoes, include the liquids from the can if possible.
4. Simmer contents of the pan and crush the tomatoes on the pan with your instrument of choice.
5. Additionally add desired herbs.

## Contribution

- Luke Smith -- [website](https://lukesmith.xyz), [donate](https://lukesmith.xyz/donate)

;tags: italian basic sauce
