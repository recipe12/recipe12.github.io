# Hellfire Steak

I first learned this recipe from a Bishop I had growing up. It produces quite a good steak despite the unconventional ingredients.


## Ingredients

- Steak
- Kosher Salt
- Mustard Powder
- Tabasco Sauce

## Directions

1. Rub a generous amount of salt all over the steak
2. Coat the entire steak with mustard powder
3. Pour Tabasco Sauce onto both sides of the steak, don't be afraid to put more on than you think you might otherwise be comfortable with the salt will cancel out a lot of the spice while grilling.
4. Grill over low heat until steak is cooked to your preference.

## Contribution

- Jacob Smith - [website](https://jacobwsmith.xyz)

;tags: beef quick
