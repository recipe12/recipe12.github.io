# Caesar Salad

![caesar_salad](pix/csalad.webp)

Caesar Salad is an easy and delicious meal for lunch or dinner.

## Ingredients

- Romaine Lettuce
- Grated Parmesan Cheese
- Croutons
- Caesar Salad Dressing

## Directions

1. Prepare a whole head of Romaine Lettuce by chopping off the root and rising thoroughly with water.  Dry completely.
2. Once the lettuce is fully dry, put in a mixing bowl with lettuce and the Caesar Salad dressing.  Toss to cover each leaf completely.
3. Add croutons.
4. Grate Parmesan over salad.
5. Eat with hands.

## Contributors

- gucko

;tags: italian salad
