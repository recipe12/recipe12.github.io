# Liver Pate

Good start for trying to eat more organs.
It even tastes very nice.
The last step before eating it raw someday.

## Ingredients

- 1lbs./500g liver (chicken, beef, poultry etc.)
- 1 Cup Carrots
- 1 Cup Onions
- 2 Teaspoon Nutmeg
- 2 Tablespoon Butter or Ghee

## Directions

1. Cut liver into cubes.
2. Put into a pot and cover with cold water, add 1tsp salt. Bring to a boil and boil for 10-15 minutes.
3. Grate carrots and dice onions. Stew in a frying pan with a little bit of water until soft.
4. In a food processor blend all ingredients together.

### Notes

With beef liver, remove its membrane, that is on top, with your fingers. Cut it in small pieces even cubes or slices and remove the vessels that are inside it. They are not very tasty and are impossible to chew.

## Contribution

- vod3 btc: `3DdikYnxPHv6Bz6qgXYoyxrcbikADqxwNd`

;tags: pate liver
