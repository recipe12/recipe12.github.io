# Yogurt

## Ingredients

- 2 thermos, ½l capacity each
- thermometer
- 1l milk
- 100ml yogurt

## Directions

- bring the milk to 45°C (113°F)
- pour the yogurt into the milk
- wisk well
- bring the milk to 45°C (113°F) again (don't go higher than that, please)
- boil some water (about 100ml) and use it to wash the thermos from inside
- let the water out and pour the milk into the thermos
- leave the thermos in the oven(or in any other place whithout air flow) for 12h
- store in the fridge

## Contribution

- italian boy

;tags: basic breakfast
