# Peanut Butter

## Ingredient

- 1 lb. of raw pre-shelled peanuts

## Directions

1. Spread peanuts on a large baking sheet and roast in the oven at 350°F (175°C) for ten to twelve minutes
2. While the peanuts are still hot remove any skins from them. This is best done by wrapping a few handfuls at a time in a dish towel and rolling them against each other for several seconds.
3. Put all your roasted and skinned peanuts in a food processor, add salt if desired, and chop until you have reached your desired thickness of peanut butter. (This may take a few minutes)

## Contribution

- Jacob Smith - [website](https://jacobwsmith.xyz)

;tags: spread snack basic
