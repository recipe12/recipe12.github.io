# Lemon juice salad dressing

A dressing that goes well on lettuce or any other mixed greens.

## Ingredients

- Lemon juice from half a lemon
- Tablespoon of olive oil
- Clove of garlic

## Directions

1. Combine lemon juice and oil in small bowl.
2. Add salt and pepper to taste.
3. Add the garlic, pressed or finely minced.
4. Mix well before adding to salad.

## Contribution

- Martin Chrzanowski -- [website](https://m-chrzan.xyz), [donate](https://m-chrzan.xyz/crypto.html)

;tags: salad basic
