# Maque Choux

An old cajun recipe for stewed corn & tomatoes. Enjoyable at any time of year, but I love to make it on hot summer afternoons as a side to
a sausage dish. Pairs well with brown ales.

## Ingredients

- A little sugar
- A good bit of grease (about a handful)
- Handful of chopped onion
- Handful of chopped bell pepper
- Eight ears of corn
- Handful of chopped tomatoes
- Salt & Pepper (to taste)

## Directions

1. Clean the corn and cut lengthwise about a thumbnail (1/4 in) from the top and scrape down using the soft end of a knife (to keep the juices).
2. Mix all ingredients in a bowl excluding the grease. Salt & pepper to taste.
3. Pour mixture into a pot with hot grease in it at low heat.
4. Cover pot and cook for 45 minutes, and stir as you get up for more beers.
5. Serve. (Serves 4-6)

## Contributors

- **Dr. Cat** -- [website](https://github.com/castrated/)

;tags: american corn
