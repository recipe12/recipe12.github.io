# Taco Meat

## Ingredients

- 1 pound (about 500 g) ground beef or turkey
- 1 medium onion, finely chopped (or 1 1/2 teaspoon onion powder)
- 1 medium tomato, chopped (or 1 small can of tomato sauce)
- 1 teaspoon chili powder (or 1/3 teaspoon each oregano, cumin, garlic powder)
- 1 teaspoon oregano (ground or leaf)
- 1/4 teaspoon cumin
- dash of pepper (1/8 teaspoon or less)

## Directions

1. Brown beef and onion together. Drain grease.
2. Add the rest of the ingredients to the browned meat.
3. Stir well.
4. Heat this mixture thoroughly.
5. Add more tomato sauce if the mixture is dry.
6. Cover and simmer for 20 minutes, or less if the mixture begins to dry out.

## Contribution

- Elias Howell -- [website](https://snarf.top)

;tags: mexican beef
