# Chicken Wings

Perfectly cooked fall off the bone buffalo wings.

## Ingredients

- Chicken wings and drums
- Enough Frank's RedHot Sauce to marinate and top dress*
- Reynold's Oven Bag

## Directions

1. Soak your wings in Franks RedHot overnight
2. Preheat your oven to 350°F (175°C)
3. Transfer wings to the Reynold's bag, seal it, and put it in the oven for an hour
4. Crank up your grill† to high heat
5. Throw the wings on the grill to char the skin and dress with a light top coat of Franks

\* **Not** the "wing sauce" version

† A pan might work, but I've only ever used a grill

## Contributors

- **Kyle Steger** -- [GitHub](https://github.com/kyleVsteger) -- _just some dude_

;tags: chicken
