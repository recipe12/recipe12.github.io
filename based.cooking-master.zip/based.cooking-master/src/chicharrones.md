# Chicharrones

## Ingredients
- Pork Butt with fat
- Adobo Goya all purpose
- Cumin
- Goya Naranja juice
- Corn oil (preferred)

## Directions

1. Cut pork butt to around bite sized pieces with fat attached for frying and flavor.
2. Add Adobo Goya and spread evenly throughout the pork
3. Add Black pepper 1 ml
4. Add Cumin 1 ml
5. Add Salt 5 ml
6. Add Goya Naranja 15 ml
7. Rub all of it to spread the spices along the meat
8. Have a colander to put the Chicharonnes in after having fried it and have another pot on the bottom that has some paper inside for oil
9. Put it in deep dish skillet around Medium (3-4) heat cover with lid for around 30-35 mins till you see it's cooked, turning to make sure everything is cooking evenly
10. After it dries up at around 30-35 mins put the temperature to High (6-7) without the lid
11. Put some oil to make sure it doesn't stick too much
12. Use spoon to spin/stir and fry until a golden brown
13. Take out the Chicharonnes and put into the colander. You may keep some of the fried bits that come off to eat as well.


## Contribution

- Abuela's Cooking 

;tags: mexican pork 



