# Bloody Mary Mix

- ⏲️ Prep time: 5 min
- 🍳Cook time: 5 min
- 🍽️ Servings: 8

## Ingredients

- 1 (46 fluid ounce) bottle tomato-vegetable juice cocktail
- 1 fruit, without seeds lemons, juiced
- 1 teaspoon brown sugar
- 1 tablespoon steak sauce
- 1 tablespoon Worcestershire sauce
- 1 teaspoon prepared horseradish
- 1 teaspoon hot pepper sauce
- 1/2 teaspoon celery salt

## Directions

1. In a large pitcher, combine juice cocktail, lemon juice and brown sugar. Season with Worcestershire sauce, horseradish, hot sauce and celery salt. Cover, and refrigerate 8 to 12 hours to allow flavors to meld.

## Contribution

Front3ndNinja - [Website](https://github.com/Front3ndNinja)

;tags: drink sweet breakfast