# Salsa Verde

## Ingredients

* 1 pound (450g) tomatillos, husks removed
* 1 clove garlic
* 2 jalapeño or serrano chiles
* 1/2 cup (26g) chopped onion
* 3 Tbsp (40ml) oil
* cilantro

## Instructions

1. Place tomatillos, garlic, and chiles in a medium saucepan and cover with water. Simmer until tomatillos turn pale green, about 10 minutes.
2. Transfer tomatillos, garlic, and chiles into a blender or food processor. Add the onion and cilantro. Puree until smooth, then salt to taste, usually a teaspoon (6g) will suffice.
3. Heat oil in a medium saucepan until hot but not smoking. Pour puree into the pan and cook, stirring occasionally, until thickened somwhat, about 6-8 minutes.

Makes about 2 cups (475mL). Refrigerate leftovers

## Contribution

-Nathan

;tags: mexican sauce
