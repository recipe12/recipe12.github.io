# Shrimp and Grits

This recipe is derived from Smokin' & Grillin' wit AB -- [youtube](https://youtu.be/cjlDBPlTqS0)

- ⏲️ Prep time: 5 min
- 🍳Cook time: 20 min
- 🍽️ Servings: 2-3

## Ingredients

- 2 lbs Large/Jumbo Shrimp
- 6 Slices of Bacon
- 1 cup Un-Cooked Grits
- 3 cups Chicken Broth
- 2 cups Shredded Cheddar Cheese
- 3 tbsp Butter
- 3 tbsp Chopped Fresh Parsley
- 1 tbsp Creole / Cajun seasoning
- 2 Cloves of Garlic, minced
- 2 tsp Worcestershire Sauce
- 1 tbsp Lemon Juice

## Directions

1. Add bacon to hot pan. Meanwhile, in separate pot , bring chicken broth to a boil. 
2. Add grits to chicken broth and stir. Cover and simmer per instructions on box.
3. Once grits are done, add butter plus salt and pepper to taste. Stir until combined.
4. Add cheese. Stir until combined.
5. Once bacon is done, keep bacon fat in the pan. Add shrimp and fry on medium-high heat
6. Add Creole seasoning, lemon juice, Worcestershire Sauce, garlic and toss. 
7. Fry until shrimp turns white on each side which is about 5-7 minutes total. 
8. In a bowl, serve shrimp and bacon over grits. Top with parsley. 

## Contribution

- Carl Zimmerman -- [website](https://codingwithcarl.com)
- Smokin' & Smokin' & Grillin' wit AB -- [youtube channel](https://www.youtube.com/channel/UC6tJ9C5SBvK6b-0cejoc4vg)

;tags: american fish breakfast
