# Chicken Biscuit Potpie Recipe

## Ingredients

- 1-2/3 cups frozen mixed vegetables, thawed
- 1-1/2 cups cubed cooked chicken
- 1 can (10-3/4 ounces) condensed cream of chicken soup, undiluted
- 1/4 teaspoon dried thyme
- 1 cup biscuit/baking mix
- 1/2 cup whole milk
- 1 large egg

## Directions

1. Preheat oven to 400°F (200°C). In a large bowl, combine the vegetables, chicken, soup and thyme. Pour into an ungreased deep-dish 9-in. pie plate. Combine the biscuit mix, milk and egg; spoon over chicken mixture.
2. Bake until topping is golden brown and toothpick inserted in the center comes out clean, 25-30 minutes.

## Contribution

Front3ndNinja - [Website](https://github.com/Front3ndNinja)

;tags: chicken
