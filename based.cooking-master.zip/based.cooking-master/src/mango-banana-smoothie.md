# Mango-Banana Smoothie

## Ingredients

- 1 banana
- 1/2 cup frozen mango pieces
- 1/3 cup plain yogurt
- 1/2 cup orange-mango juice blend

## Directions

1. Combine the banana, mango, yogurt, and juice in a blender; blend until nearly smooth.

## Contribution

Front3ndNinja - [Website](https://github.com/Front3ndNinja)

;tags: drink sweet breakfast