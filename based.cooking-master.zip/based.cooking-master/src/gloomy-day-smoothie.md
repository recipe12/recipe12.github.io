# Gloomy Day Smoothie

## Ingredients

- 1 mango - peeled, seeded, and cut into chunks
- 1 banana, peeled and chopped
- 1 cup orange juice
- 1 cup vanilla nonfat yogurt

## Directions

1. Place mango, banana, orange juice, and yogurt in a blender. Blend until smooth. Serve in clear glasses, and drink with a bendy straw!

## Contribution

Front3ndNinja - [Website](https://github.com/Front3ndNinja)

;tags: drink sweet breakfast