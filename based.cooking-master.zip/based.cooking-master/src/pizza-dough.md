# Pizza dough
here is a simple recipe for Pizza dough
Basicly you have to use a 2/1 (flour/liqud) ratio.
if you use other flour like rye, you may need more liquid.

## Ingredients

- 400 g Flour (Basic Wheat flour)
- 200 ml lukewarm Water
- 1 pkg (7g) dry yeast
- 1 spoon olive oil
- 1 teaspoon salt
- a litte bit sugar (to feed the yeast)

## Directions
1. combine all ingredients all in a bowl and knead to a dough.
2. let it rest for 30 min in a luke warm place.
3. then flour the work surface and roll it out thinly

## Contribution

BeFe

;tags: basic
