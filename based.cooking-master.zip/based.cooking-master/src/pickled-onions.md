# Pickled Red Onions

A good way to use up older red onions and goes great with just about anything.

- ⏲️ Prep time: 10 min
- 🍳Cook time: 10 min
- 🍽️ Servings Varies

## Ingredients

- Red Onions
- Vinegar
- Water

## Directions

1. Cut onion in half and slice root to stem and place in a jar
2. Mix equal parts of water and vinegar in a pot and bring to a boil. Add salt to taste
3. As soon as it begins to boil, turn off and pour the mix into the jar and allow to cool.
4. Seal and place in fridge for a few hours until vibrant pink.

## Notes
- You can add other herbs or spices before sealing it to give different flavors as well. Use any of your standard pickling spices if desired.

## Contribution

- AJ XMR: `45kYSzfMbY79HeuFoJC2sSGwoXCkty7X6F8nD7rNMkmuZvsDwoAnxDk3B1bT4rK2Je6z9cvKoxxGqS7aUbzvQajzEcK8nfQ`

;tags: quick side basic
