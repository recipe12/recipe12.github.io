# Peanut Butter Banana Smoothie

- ⏲️ Prep time: 5 min
- 🍳Cook time: 5 min
- 🍽️ Servings: 4

## Ingredients

- 2 bananas, broken into chunks
- 2 cups milk
- 1/2 cup peanut butter
- 2 tablespoons honey, or to taste
- 2 cups ice cubes

## Directions

1. Place bananas, milk, peanut butter, honey, and ice cubes in a blender; blend until smooth, about 30 seconds.

## Contribution

Front3ndNinja - [Website](https://github.com/Front3ndNinja)

;tags: drink sweet breakfast