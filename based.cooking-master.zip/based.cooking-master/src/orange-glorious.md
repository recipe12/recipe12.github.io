# Orange Glorious

- ⏲️ Prep time: 5 min
- 🍳Cook time: 5 min
- 🍽️ Servings: 4

## Ingredients

- 1 (6 ounce) can frozen orange juice concentrate
- 1 cup milk
- 1 cup water
- 1/2 cup white sugar
- 1 teaspoon vanilla extract
- 12 cubes ice

## Directions

1. In a blender, combine orange juice concentrate, milk, water, sugar and vanilla. Add ice cubes and blend until smooth. Pour into glasses and serve.

## Contribution

Front3ndNinja - [Website](https://github.com/Front3ndNinja)

;tags: drink sweet breakfast