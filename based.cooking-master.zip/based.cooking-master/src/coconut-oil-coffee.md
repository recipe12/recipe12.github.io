# Coconut Oil Coffee

## Ingredients

- 2 cups hot coffee
- 2 tablespoons coconut oil
- 2 tablespoons unsalted butter

## Directions

1. Blend coffee, coconut oil, and butter together in a blender until oil and butter are melted and coffee is frothy.

## Contribution

Front3ndNinja - [Website](https://github.com/Front3ndNinja)

;tags: drink sweet breakfast