# Cannellini Bean Salad

- ⏲️ Prep time: 5 min
- 🍳Cook time: 10 min
- 🍽️ Servings: 2

## Ingredients

- 1 can Cannellini beans, drained and rinsed
- 2 tbsp minced garlic 
- 1/2 onion
- 1 tsp smoked paprika
- 1/2 tsp ground cumin
- 1 15 oz can diced tomatoes
- 1 tbsp parsley flakes
- Prosciutto
- Arugula 

## Directions

1. Sauté garlic and onions in olive oil until onions are translucent.
2. Add diced tomatoes, seasonings, and salt and pepper to taste. Simmer for 3 minutes.
3. Add the beans, season to taste, mix until combined, and simmer for an additional 2 minutes.
4. Serve over arugula and top with bits of prosciutto. 

## Contribution

- Carl Zimmerman -- [website](https://codingwithcarl.com)

;tags: beans italian salad
