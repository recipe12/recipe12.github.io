# Fried Potatoes

## Ingredients
- Potatoes
- Oil or Crème Fraîche
- Onions

## Directions
1. Peel and cut the potatoes to desired size.
2. Cut the onions.
3. Put a bit of Oil or Crème Fraîche in your pan.
4. Put both the potatoes and the onions into the pan.
5. Cook them until they're golden-brown.
6. Enjoy

## Contribution
themisch - [website](http://k63fspwi7eekmjy7i3ofk425lseyftfrbikyjs5ndgrvzasxlh6hoiid.onion), [donate](http://k63fspwi7eekmjy7i3ofk425lseyftfrbikyjs5ndgrvzasxlh6hoiid.onion/donate.html)

;tags: potato quick side
