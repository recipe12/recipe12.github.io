# Russian 1000 Islands Sauce

A tasty sauce that goes well with salads or rice. Recipe taken from a Russian monastery.

## Ingredients

- Ketchup (Sir Kensington's recommended)
- Mayonnaise
- Horseradish
- Worchestershire sauce
- Paprika
- Dijon mustard
- Onion powder
- Pickle relish (optional)

## Directions

1. Take ingredients,
2. Put into bowl or cup,
3. Mix together thoroughly,
4. Done.

## Contribution

- Anon

;tags: basic spread quick russian
