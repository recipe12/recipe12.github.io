# Hamburger Patties

🍽️ Servings: 6 patties

## Ingredients

-   1 cup soft bread crumb
-   1/2 cup milk
-   1 1/2 pound ground beef
-   1 medium onion, chopped
-   1/2 teaspoon salt
-   dash pepper
-   1/2 teaspoon cayenne
-   1 teaspoon Worcestershire sauce
-   2 tablespoons of fat or salad oil

## Directions

1.  Combine all ingredients except fat: mix well; shape into 6 patties.
2.  Heat fat in skillet.
3.  Brown patties on all sides; lower heat; cook to desired degree of
    doneness.

## Contribution

- Anonymous
            
;tags: american quick beef sandwich
