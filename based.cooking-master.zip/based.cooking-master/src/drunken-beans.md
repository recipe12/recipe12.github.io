# Drunken beans (Pintos Borrachos)
 
Pinto beans cooking with beer, what beer you use can change the dish.

## Ingredients

- 1 small yellow onion
- 3 gloves of garlic
- 2 tomatoes. chopped
- 4 cups of water
- 1 1/2 cups of pinto beans (can be dried or canned)
- 1 tbsp oregano
- 3/4 tsp cumin
- 2 tbsp chilli powder(depends how hot you like it)
- 12oz of Beer/dark ale

## Directions

1. Sauté onions. 
2. Add garlic, sauté bit longer.
3. Add tomatoes, water, beans, oregano, cumin, chilli powder, beer and salt, gradually bring to boil. 
4. When boiled, reduce to simmer.
5. When beans are al dente (about 1 hour if using dried), bring to quick boil and evaporate remaining liquid until beans are stew-like.
6. Remove from the heat and mashup, or skip this step if you want more of a bean stew.


## Contribution

- just a dude who likes cooking

;tags: beans stew
